// ================
// Header Sticky
// ================
$(document).ready(function ($) {
  var slideHeader = new SlideHeader($('.main-header'));
});

function SlideHeader(el) {
  this.initialize(el);
  this.onScroll();
}

SlideHeader.prototype.initialize = function (el) {
  this.$el = el;
  this.$window = $(window);

  this.start_pos = 0;

}

SlideHeader.prototype.onScroll = function () {
  var self = this;

  var _touch = ('ontouchstart' in document) ? 'touchmove' : 'scroll';
  this.$window.on(_touch, function () {
    var $current_pos = $(window).scrollTop();

    if ($current_pos > 108) {
      if ($current_pos > self.start_pos) {
        self.slideOut();
      } else {
        self.slideIn();
      }
    } else {
      self.slideIn();
    }
    self.start_pos = $current_pos;
  });
}

SlideHeader.prototype.slideIn = function () {
  this.$el.removeClass('is-slideout');
}

SlideHeader.prototype.slideOut = function () {
  this.$el.addClass('is-slideout');
}


//Slick slider
$(document).ready(function ($) {
  $('.product-slider').slick({
    // centerMode: true,
    slidesToShow: 3.5,
    infinite: false,
    slidesToScroll: 1,
    focusOnSelect: false,
    accessibility: true,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 769,
        settings: {
          arrows: true,
          slidesToShow: 2
        }
      },
      {
        breakpoint: 769,
        settings: {
          slidesToShow: 1
        }
      },
    ]
  });

  // Testimonial slider
  $('.testimonial-slider').slick({
    infinite: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    focusOnSelect: false,
    accessibility: true,
  });

  // Our Product slider
  $('.our-product').slick({
    // centerMode: true,
    slidesToShow: 6,
    arrows: false,
    infinite: false,
    slidesToScroll: 1,
    focusOnSelect: false,
    accessibility: true,
    // responsive: [
    //   {
    //     breakpoint: 1200,
    //     settings: {
    //       slidesToShow: 3
    //     }
    //   },
    //   {
    //     breakpoint: 769,
    //     settings: {
    //       slidesToShow: 2
    //     }
    //   },
    //   {
    //     breakpoint: 769,
    //     settings: {
    //       slidesToShow: 1
    //     }
    //   },
    // ]
  }); 
});

// ================
// Search bar
// ================ 
$('.search-icon').click(function () {
  $('.search-bar').addClass('active');
});
$('.close-search').click(function () {
  $('.search-bar').removeClass('active');
});

$('.navbar-toggler').click(function () {
  $('.overlay-bg').addClass('active');
})
$('.close-navbar').click(function () {
  $('.overlay-bg').removeClass('active');
})